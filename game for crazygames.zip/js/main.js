(function () {
  "use strict";
  window.NS = window.NS || {};

  const $ = function (id) { return document.getElementById(id); };
  const canvas = $("game");
  const titleScreen = $("title-screen");
  const gameOverScreen = $("game-over");
  const hud = $("hud");
  const scoreEl = $("score");
  const bestEl = $("best");
  const finalScoreEl = $("final-score");
  const finalBestEl = $("final-best");
  const comboFlash = $("combo-flash");
  const startBtn = $("start-btn");
  const retryBtn = $("retry-btn");
  const reviveBtn = $("revive-btn");
  const muteBtn = $("mute-btn");
  const muteIcon = $("mute-icon");
  const pauseBtn = $("pause-btn");
  const resumeBtn = $("resume-btn");
  const menuBtnPause = $("menu-btn-pause");
  const menuBtnGo = $("menu-btn-go");
  const pauseOverlay = $("pause-overlay");
  const bannerWrap = $("banner-bottom");
  const modeBtns = document.querySelectorAll(".mode-btn");

  let comboTimer = null;
  let lastGameOver = 0;
  const GAME_OVER_COOLDOWN = 400;

  const game = new NS.Game(canvas, {
    onScore: function (s) { scoreEl.textContent = s; },
    onCombo: function (combo) {
      comboFlash.textContent = combo >= 2 ? ("PERFECT x" + combo) : "PERFECT";
      comboFlash.classList.remove("pop");
      void comboFlash.offsetWidth;
      comboFlash.classList.add("pop");
      clearTimeout(comboTimer);
      comboTimer = setTimeout(function () { comboFlash.classList.remove("pop"); }, 650);
    },
    onGameOver: function (score, best, canRevive) {
      lastGameOver = Date.now();
      finalScoreEl.textContent = score;
      finalBestEl.textContent = best;
      reviveBtn.style.display = canRevive ? "" : "none";
      pauseBtn.style.display = "none";
      hud.classList.remove("show");
      gameOverScreen.classList.remove("hidden");
      maybeShowBanner();
    },
    onReturnToMenu: function () {
      hideScreens();
      pauseOverlay.classList.add("hidden");
      pauseBtn.style.display = "none";
      hud.classList.remove("show");
      titleScreen.classList.remove("hidden");
      clearBanners();
    }
  });

  function showHud() { hud.classList.add("show"); pauseBtn.style.display = ""; }
  function hideScreens() {
    titleScreen.classList.add("hidden");
    gameOverScreen.classList.add("hidden");
  }

  function startRun() {
    NS.audio.init();
    NS.audio.start();
    hideScreens();
    pauseOverlay.classList.add("hidden");
    showHud();
    game.newRun();
    if (NS.sdk.available) NS.sdk.gameplayStart();
    clearBanners();
  }

  function retry() {
    if (Date.now() - lastGameOver < GAME_OVER_COOLDOWN) return;
    NS.audio.click();
    if (NS.sdk.available) {
      NS.sdk.showMidgameAd().then(function () { startRun(); });
    } else {
      startRun();
    }
  }

  function revive() {
    if (!NS.sdk.available) { retry(); return; }
    NS.audio.click();
    reviveBtn.style.display = "none";
    NS.sdk.showRewardedAd().then(function (success) {
      if (success && game.revive()) {
        hideScreens();
        showHud();
        if (NS.sdk.available) NS.sdk.gameplayStart();
      } else {
        startRun();
      }
    });
  }

  function primaryAction() {
    if (game.state === "title") { startRun(); return; }
    if (game.state === "playing") { game.drop(); return; }
    if (game.state === "paused") { togglePause(); return; }
  }

  function togglePause() {
    if (game.state === "playing") {
      game.pause();
      pauseOverlay.classList.remove("hidden");
    } else if (game.state === "paused") {
      game.resume();
      pauseOverlay.classList.add("hidden");
    }
  }

  function returnToMenu() {
    NS.audio.click();
    pauseOverlay.classList.add("hidden");
    game.returnToMenu();
  }

  startBtn.addEventListener("click", function (e) { e.stopPropagation(); startRun(); });
  retryBtn.addEventListener("click", function (e) { e.stopPropagation(); retry(); });
  reviveBtn.addEventListener("click", function (e) { e.stopPropagation(); revive(); });
  pauseBtn.addEventListener("click", function (e) { e.stopPropagation(); togglePause(); });
  resumeBtn.addEventListener("click", function (e) { e.stopPropagation(); togglePause(); });
  menuBtnPause.addEventListener("click", function (e) { e.stopPropagation(); returnToMenu(); });
  menuBtnGo.addEventListener("click", function (e) { e.stopPropagation(); returnToMenu(); });

  canvas.addEventListener("pointerdown", function (e) {
    if (game.state === "playing" || game.state === "paused") { e.preventDefault(); primaryAction(); }
    else if (game.state === "gameover") { e.preventDefault(); retry(); }
  });
  window.addEventListener("keydown", function (e) {
    if (e.code === "Space" || e.code === "Enter") {
      e.preventDefault();
      if (game.state === "title") { startRun(); return; }
      if (game.state === "gameover") { if (Date.now() - lastGameOver >= GAME_OVER_COOLDOWN) retry(); return; }
      primaryAction();
    } else if (e.code === "Escape") {
      e.preventDefault();
      togglePause();
    } else if (e.key === "m" || e.key === "M") {
      toggleMute();
    }
  });

  let muted = localStorage.getItem("neonstack_muted") === "true";
  NS.audio.setMuted(muted);
  muteIcon.innerHTML = muted ? "&#128263;" : "&#128266;";
  function toggleMute() {
    muted = !muted;
    NS.audio.setMuted(muted);
    localStorage.setItem("neonstack_muted", muted ? "true" : "false");
    muteIcon.innerHTML = muted ? "&#128263;" : "&#128266;";
  }
  muteBtn.addEventListener("click", function (e) { e.stopPropagation(); toggleMute(); });

  function updateBest() {
    var key = "neonstack_best_" + game.difficulty;
    var best = parseInt(localStorage.getItem(key) || "0", 10) || 0;
    bestEl.textContent = "BEST " + best;
  }

  modeBtns.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var mode = btn.getAttribute("data-mode");
      game.setDifficulty(mode);
      localStorage.setItem("neonstack_mode", mode);
      modeBtns.forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      updateBest();
    });
  });

  var validModes = ["easy", "medium", "hard"];
  var storedMode = localStorage.getItem("neonstack_mode") || "medium";
  if (validModes.indexOf(storedMode) >= 0) {
    game.setDifficulty(storedMode);
    modeBtns.forEach(function (b) {
      if (b.getAttribute("data-mode") === storedMode) b.classList.add("active");
      else b.classList.remove("active");
    });
  }

  (function initBestDisplay() { updateBest(); })();

  let bannerTimer = null;
  function maybeShowBanner() {
    if (!NS.sdk.available) return;
    const isWide = window.innerWidth >= 768;
    const w = isWide ? 728 : 320;
    const h = isWide ? 90 : 50;
    bannerWrap.style.height = h + "px";
    let inner = bannerWrap.querySelector("div");
    if (!inner) {
      inner = document.createElement("div");
      inner.id = "cg-banner-inner";
      inner.style.width = w + "px";
      inner.style.height = h + "px";
      bannerWrap.appendChild(inner);
    }
    game.resize();
    NS.sdk.requestBanner("cg-banner-inner", w, h);
    clearInterval(bannerTimer);
    bannerTimer = setInterval(function () {
      NS.sdk.requestBanner("cg-banner-inner", w, h);
    }, 35000);
  }
  function clearBanners() {
    if (!NS.sdk.available) return;
    clearInterval(bannerTimer);
    bannerWrap.style.height = "0px";
    NS.sdk.clearBanners();
    game.resize();
  }

  (async function boot() {
    pauseBtn.style.display = "none";
    if (NS.sdk.available === false && !NS.sdk.ready) {
      try { await NS.sdk.init(); } catch (e) {}
    }
    if (NS.sdk.available) {
      NS.sdk.loadingStart();
      NS.sdk.loadingStop();
    }
    if (NS.sdk.available) {
      const sdk = window.CrazyGames.SDK;
      const settings = sdk.game && sdk.game.settings;
      if (settings && settings.muteAudio) NS.audio.setExternalMute(true);
      if (sdk.game && typeof sdk.game.addSettingsChangeListener === "function") {
        sdk.game.addSettingsChangeListener(function (updated) {
          if (updated.muteAudio !== undefined) NS.audio.setExternalMute(!!updated.muteAudio);
        });
      }
    }
    game.startLoop();
  })();
})();
